package contact;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    void testCreateValidAppointment() {
        Date future = new Date(System.currentTimeMillis() + 60_000); // 1 min in future
        Appointment a = new Appointment("A123", future, "Oil change appointment");

        assertEquals("A123", a.getAppointmentId());
        assertEquals(future, a.getAppointmentDate());
        assertEquals("Oil change appointment", a.getDescription());
    }

    @Test
    void testAppointmentIdNullThrows() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(null, future, "Desc"));
    }

    @Test
    void testAppointmentIdTooLongThrows() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345678901", future, "Desc")); // 11 chars
    }

    @Test
    void testAppointmentDateNullThrows() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("A1", null, "Desc"));
    }

    @Test
    void testAppointmentDateInPastThrows() {
        Date past = new Date(System.currentTimeMillis() - 60_000);
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("A1", past, "Desc"));
    }

    @Test
    void testDescriptionNullThrows() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("A1", future, null));
    }

    @Test
    void testDescriptionTooLongThrows() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        String longDesc = "x".repeat(51);
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("A1", future, longDesc));
    }

    @Test
    void testUpdateDateValid() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        Appointment a = new Appointment("A1", future, "Desc");

        Date future2 = new Date(System.currentTimeMillis() + 120_000);
        a.setAppointmentDate(future2);
        assertEquals(future2, a.getAppointmentDate());
    }

    @Test
    void testUpdateDatePastThrows() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        Appointment a = new Appointment("A1", future, "Desc");

        Date past = new Date(System.currentTimeMillis() - 60_000);
        assertThrows(IllegalArgumentException.class, () -> a.setAppointmentDate(past));
    }

    @Test
    void testUpdateDescriptionValid() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        Appointment a = new Appointment("A1", future, "Desc");

        a.setDescription("New description");
        assertEquals("New description", a.getDescription());
    }

    @Test
    void testUpdateDescriptionTooLongThrows() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        Appointment a = new Appointment("A1", future, "Desc");

        assertThrows(IllegalArgumentException.class, () ->
                a.setDescription("x".repeat(51)));
    }
}
