package contact;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("task cannot be null");
        }
        String id = task.getTaskId();
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("taskId must be unique");
        }
        tasks.put(id, task);
    }

    public void deleteTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("taskId cannot be null");
        }
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("taskId does not exist");
        }
        tasks.remove(taskId);
    }

    public void updateName(String taskId, String name) {
        getExisting(taskId).setName(name);
    }

    public void updateDescription(String taskId, String description) {
        getExisting(taskId).setDescription(description);
    }

    // Helpful for tests
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    private Task getExisting(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("taskId cannot be null");
        }
        Task t = tasks.get(taskId);
        if (t == null) {
            throw new IllegalArgumentException("taskId does not exist");
        }
        return t;
    }
}
