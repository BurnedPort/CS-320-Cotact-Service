package contact;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    @Test
    void testAddAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment a = new Appointment("A1", new Date(System.currentTimeMillis() + 60_000), "Desc");

        service.addAppointment(a);

        assertEquals(1, service.size());
        assertNotNull(service.getAppointment("A1"));
    }

    @Test
    void testAddAppointmentDuplicateIdThrows() {
        AppointmentService service = new AppointmentService();
        Appointment a1 = new Appointment("A1", new Date(System.currentTimeMillis() + 60_000), "Desc");
        Appointment a2 = new Appointment("A1", new Date(System.currentTimeMillis() + 120_000), "Desc2");

        service.addAppointment(a1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(a2));
    }

    @Test
    void testDeleteAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment a = new Appointment("A1", new Date(System.currentTimeMillis() + 60_000), "Desc");

        service.addAppointment(a);
        service.deleteAppointment("A1");

        assertEquals(0, service.size());
        assertNull(service.getAppointment("A1"));
    }

    @Test
    void testDeleteNonexistentThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("NOPE"));
    }

    @Test
    void testDeleteNullIdThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
    }
}
