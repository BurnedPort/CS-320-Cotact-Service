package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddTaskSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Task Name", "Task Description");
        service.addTask(task);

        assertNotNull(service.getTask("1"));
        assertEquals("Task Name", service.getTask("1").getName());
    }

    @Test
    void testAddTaskNull() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.addTask(null));
    }

    @Test
    void testAddTaskDuplicateId() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "A", "Desc A"));

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(new Task("1", "B", "Desc B"));
        });
    }

    @Test
    void testDeleteTaskSuccess() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Task", "Desc"));
        service.deleteTask("1");

        assertNull(service.getTask("1"));
    }

    @Test
    void testDeleteTaskNullId() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask(null));
    }

    @Test
    void testDeleteTaskNonexistentId() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("nope"));
    }

    @Test
    void testUpdateNameSuccess() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Old", "Desc"));

        service.updateName("1", "New");
        assertEquals("New", service.getTask("1").getName());
    }

    @Test
    void testUpdateDescriptionSuccess() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Name", "Old"));

        service.updateDescription("1", "New Desc");
        assertEquals("New Desc", service.getTask("1").getDescription());
    }

    @Test
    void testUpdateNameInvalidId() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.updateName("nope", "New"));
    }

    @Test
    void testUpdateDescriptionInvalidId() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("nope", "New"));
    }
}
