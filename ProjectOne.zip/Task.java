package contact;

public class Task {
    private final String taskId; // not updatable
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        validateTaskId(taskId);
        validateName(name);
        validateDescription(description);

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() { return taskId; }
    public String getName() { return name; }
    public String getDescription() { return description; }

    public void setName(String name) {
        validateName(name);
        this.name = name;
    }

    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

    private static void validateTaskId(String id) {
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("taskId must be non-null and <= 10 chars");
        }
    }

    private static void validateName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("name must be non-null and <= 20 chars");
        }
    }

    private static void validateDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("description must be non-null and <= 50 chars");
        }
    }
}
