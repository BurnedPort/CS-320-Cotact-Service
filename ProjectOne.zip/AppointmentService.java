package contact;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();

    // Requirement: add appointments with a unique appointment ID
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment must not be null.");
        }
        String id = appointment.getAppointmentId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment ID must be unique.");
        }
        appointments.put(id, appointment);
    }

    // Requirement: delete appointments per appointment ID
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null) {
            throw new IllegalArgumentException("Appointment ID must not be null.");
        }
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("No appointment found with that ID.");
        }
        appointments.remove(appointmentId);
    }

    // Helper for tests / debugging (safe to include)
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }

    // Helper for tests
    public int size() {
        return appointments.size();
    }
}
