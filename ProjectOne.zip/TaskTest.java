package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testCreateTaskSuccess() {
        Task task = new Task("12345", "My Task", "This is a description.");
        assertEquals("12345", task.getTaskId());
        assertEquals("My Task", task.getName());
        assertEquals("This is a description.", task.getDescription());
    }

    @Test
    void testTaskIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Desc");
        });
    }

    @Test
    void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Desc");
        });
    }

    @Test
    void testNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Desc");
        });
    }

    @Test
    void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "123456789012345678901", "Desc"); // 21 chars
        });
    }

    @Test
    void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Name", null);
        });
    }

    @Test
    void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Name",
                    "123456789012345678901234567890123456789012345678901"); // 51 chars
        });
    }

    @Test
    void testSetNameSuccess() {
        Task task = new Task("12345", "Old", "Desc");
        task.setName("New");
        assertEquals("New", task.getName());
    }

    @Test
    void testSetNameInvalid() {
        Task task = new Task("12345", "Old", "Desc");
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
    }

    @Test
    void testSetDescriptionSuccess() {
        Task task = new Task("12345", "Name", "Old");
        task.setDescription("New Desc");
        assertEquals("New Desc", task.getDescription());
    }

    @Test
    void testSetDescriptionInvalid() {
        Task task = new Task("12345", "Name", "Old");
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
    }
}
